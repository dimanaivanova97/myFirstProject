public class firstTask {

    public static void main(String[] args) {
        String firstName = new String("Dimana");
        String secondName = new String("Zlateva");
        String lastName = new String("Ivanova");

        System.out.println(firstName + " " + secondName + " " + lastName);
    }
}
