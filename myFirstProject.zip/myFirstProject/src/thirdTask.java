public class thirdTask {
    public static void main(String[] args) {

        double a = 6;
        double b = 3;

        double triangleArea = a * b / 2;

        System.out.println("Triangle area is equal to: " + triangleArea + "cm");
    }
}
