public class secondTask {
    public static void main(String[] args) {

        double a = 5;
        double b = 6;
        double c = 7;

        double trianglePerimeter = a + b + c;

        System.out.println("Perimeter of the triangle is: "+ trianglePerimeter + "cm");
    }
}
