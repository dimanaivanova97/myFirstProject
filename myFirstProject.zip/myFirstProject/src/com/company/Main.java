package com.company;

import java.util.Scanner;

public class Main {
}
